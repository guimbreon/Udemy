public class HealthyBurger extends Hamburger{
    public HealthyBurger(String meat, double price) {
        super("Healthy burger", meat,"vegan bread", price);
    }
    private double healthyExtra1Price;

  private double healthyExtra2Price;

    private String healthyExtra1Name;

    private String healthyExtra2Name;

    public void addHealthyAddition1(double healthyExtra1Price, String healthyExtra1Name){
        this.addHamburgerAddition1(healthyExtra1Price,healthyExtra1Name);
    }
    public void addHealthyAddition2(double healthyExtra2Price, String healthyExtra2Name){
        this.addHamburgerAddition2(healthyExtra2Price,healthyExtra2Name);
    }

    @Override
    public double itemizehamburger() {
        return super.itemizehamburger();
    }
}
