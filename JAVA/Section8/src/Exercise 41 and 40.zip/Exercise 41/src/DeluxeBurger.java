public class DeluxeBurger extends Hamburger{
    public DeluxeBurger(String name, String meat, String breadRollType, double price) {
        super(name = "deluxe burger with all the fixings and chips and a drink", meat, breadRollType, price = 19.10);
    }

    @Override
    public void addHamburgerAddition1(double addition1price, String addition1Name) {
        System.out.println("No extra things!");
    }

    @Override
    public void addHamburgerAddition2(double addition2price, String addition2Name) {
        System.out.println("No extra things!");
    }

    @Override
    public void addHamburgerAddition3(double addition3price, String addition3Name) {
        System.out.println("No extra things!");
    }

    @Override
    public void addHamburgerAddition4(double addition4price, String addition4Name) {
        System.out.println("No extra things!");
    }
}
