public class Hamburger {
    private String name;
    private String meat;
    private String breadRollType;
    private double price;

    public Hamburger(String name, String meat, String breadRollType, double price) {
        this.name = name;
        this.meat = meat;
        this.breadRollType = breadRollType;
        this.price = price;
    }
    private String addition1Name;
    private double addition1price;
    private String addition2Name;
    private double addition2price;
    private String addition3Name;
    private double addition3price;
    private String addition4Name;
    private double addition4price;

    public void addHamburgerAddition1(double addition1price, String addition1Name){
        this.name += addition1Name;
        this.price += addition1price;
    }
    public void addHamburgerAddition2(double addition2price, String addition2Name){
        this.name += addition2Name;
        this.price += addition2price;
    }
    public void addHamburgerAddition3(double addition3price, String addition3Name){
        this.name += addition3Name;
        this.price += addition3price;
    }
    public void addHamburgerAddition4(double addition4price, String addition4Name){
        this.name += addition4Name;
        this.price += addition4price;
    }

    public double itemizehamburger(){
        System.out.println(this.name);
        return price;
    }




}
